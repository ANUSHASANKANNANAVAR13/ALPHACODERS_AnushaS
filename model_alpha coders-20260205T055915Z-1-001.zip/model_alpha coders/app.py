
# Import necessary libraries
from flask import Flask, render_template, request
import pickle
import numpy as np

# Initialize Flask app
app = Flask(__name__)

# Load the trained Random Forest model
MODEL_PATH = "random_forest.pkl"
with open(MODEL_PATH, "rb") as model_file:
    rf_model = pickle.load(model_file)

@app.route("/")
def index():
    """Render the home page."""
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    """Handle prediction requests from the form."""
    try:
        # Extract only the required features from the form
        feature_names = [
            "acousticness", "danceability", "energy", "instrumentalness",
            "liveness", "speechiness", "valence", "loudness", "tempo"
        ]
        input_values = []
        # Indices 0-6: divide by 10, 7-8: keep as is
        for idx, name in enumerate(feature_names):
            value = request.form.get(name)
            if value is None:
                raise ValueError(f"Missing value for {name}")
            val = float(value)
            if idx <= 6:  # acousticness to valence
                val = val / 10.0
            input_values.append(val)
        input_array = np.array([input_values])

        # Make prediction using the loaded Random Forest model
        prediction_result = rf_model.predict(input_array)

        return render_template(
            "index.html",
            prediction_text=f"Predicted Music Genre: {prediction_result[0]}"
        )
    except Exception as error:
        return render_template(
            "index.html",
            prediction_text=f"Error in input values: {error}"
        )

if __name__ == "__main__":
    app.run(debug=True)
